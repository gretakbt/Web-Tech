from django.contrib import admin
from .models import Task, Group

admin.site.register(Task)
admin.site.register(Group)